+++
date = "2015-03-17T15:36:56Z"
title = "Getting Started"
[menu.main]
  identifier = "Getting Started"
  weight = 30
  pre = "<i class='fa fa-road'></i>"
+++

## Getting Started

To help you get started quickly with Morphia follow:

  * [Installation]({{< ref "getting-started/installation-guide.md" >}})
  * [Quick Tour]({{< ref "getting-started/quick-tour.md" >}})
