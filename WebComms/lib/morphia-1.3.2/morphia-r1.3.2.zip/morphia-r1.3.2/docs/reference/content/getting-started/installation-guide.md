+++
date = "2015-03-17T15:36:56Z"
title = "Installation Guide"
[menu.main]
  parent = "Getting Started"
  identifier = "Installation Guide"
  weight = 1
  pre = "<i class='fa'></i>"
+++

# Installation

The recommended way to get started using Morphia in your project is with a dependency management system.

{{< distroPicker >}}

{{< install version="1.4.0-SNAPSHOT" >}}
